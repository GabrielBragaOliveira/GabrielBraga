/*
 * Copyright (C) 2024 Gabriel Braga Oliveira <ninjagamer9795286@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package avaliacao.n1;
import java.util.Scanner;
/**
 *
 * @author Gabriel Braga Oliveira <ninjagamer9795286@gmail.com>
 * @date 08/03/2024
 * @brief Class Prova1
 */
public class Prova1 {
     public static void main(String[] args) {
        
         //criação de variaveis inteiros
        int opcao = 0, opcao2=0, opcao3, qde_expresso=0, qde_capuccino=0, 
            qde_leite_com_cafe=0, qde_cafes_vendidos;
        int fin = 0;
        //criação de variaveis double
        double valor_expresso, valor_capuccino,
            valor_leite_com_cafe, valor_cafes_vendidos;
        
        // função para ler
        Scanner sc = new Scanner(System.in);
        
        // estrutura para poder adicionar ou retirar um produto
        do {
            // estrutura de repetição para saber a quantidade de café
            do {
        
                System.out.println("Forneça uma opção: \n"+
                                    "1 ­ café expresso; \n"+
                                    "2 ­ café capuccino; \n"+
                                    "3 ­ leite com café; \n"+
                                    "4 ­ totalizar vendas;");
      
                opcao = sc.nextInt();
                
                // para saber e adicionar a qual o café e a quantidade
                if ( opcao == 1 ) qde_expresso++;
                else if (opcao == 2) qde_capuccino++;
                else if (opcao == 3) qde_leite_com_cafe++;
                else if (opcao != 4) System.out.println("Opção inválida");
      
        } while ( opcao != 4);
        
        System.out.println("Deseja adicionar mais um produto em sua lista de compra? ");
         System.out.println("Forneça uma opção: \n"+
                                    "1 ­ sim; \n"+
                                    "2 ­ não;");
         opcao2 =sc.nextInt();
         if(opcao2==1){
             continue;
             /*if(opcao2 > 2 && opcao2<1){
             do{
             System.out.println("Opção inválida");
             System.out.println("Forneça uma opção: \n"+
                                    "1 ­ sim; \n"+
                                    "2 ­ não;");
             opcao2 =sc.nextInt();
             }while(opcao ==1 || opcao==2)
         }*/
         }else if(opcao2==2){ 
             
             opcao = 0;
             opcao2 = 0;
             System.out.println("Deseja retirar algum produto em sua lista de compra? ");
             System.out.println("Forneça uma opção: \n"+
                                    "1 ­ sim; \n"+
                                    "2 ­ não;");
             opcao2 =sc.nextInt();
             if(opcao2 ==1){
                  do {
                 System.out.println("Forneça uma opção: \n"+
                                    "1 ­ café expresso; \n"+
                                    "2 ­ café capuccino; \n"+
                                    "3 ­ leite com café; \n"+
                                    "4 ­ totalizar vendas;");
                 opcao = sc.nextInt();
                
                // para saber retirar a qual o café e a quantidade
                if ( opcao == 1 ) qde_expresso--;
                else if (opcao == 2) qde_capuccino--;
                else if (opcao == 3) qde_leite_com_cafe--;
                else if (opcao != 4) System.out.println("Opção inválida");
                } while ( opcao != 4);
         System.out.println("Deseja adicionar mais um produto em sua lista de compra? ");
         System.out.println("Forneça uma opção: \n"+
                                    "1 ­ sim; \n"+
                                    "2 ­ não;");
         opcao2 =sc.nextInt();
         if(opcao2==1){
             continue;
         }
                 
             }else{
                 opcao2=2;
             }
         
         }   
        }while (opcao2!=2);
        
        // saber o valor total da quantidade de café expressos 
        valor_expresso = qde_expresso*0.75;
        // saber o valor total da quantidade de café capuccino
        valor_capuccino = qde_capuccino;
        // saber o valor total da quantidade de café com leite 
        valor_leite_com_cafe = qde_leite_com_cafe*1.25;  
        // saber a  quantidade de café vendidos 
        qde_cafes_vendidos = qde_expresso + qde_capuccino + qde_leite_com_cafe;
        // saber o valor total da quantidade de café vendido
        valor_cafes_vendidos = valor_expresso + valor_capuccino + valor_leite_com_cafe;
        
        //exibir na tela a quantidade de cada café e seu total com seus valores respectivos
        System.out.println("Qde café expresso: "+qde_expresso+" ­ valor: "+valor_expresso);
        System.out.println("Qde café capuccino: "+qde_capuccino+" ­ valor: "+valor_capuccino);    
        System.out.println("Qde leite com café: "+qde_leite_com_cafe+
                            " ­ valor: "+valor_leite_com_cafe);        
        System.out.println("Qde cafés vendidos: "+ qde_cafes_vendidos +
                            " ­ valor cafés vendidos: "+valor_cafes_vendidos);
        
        System.out.println();
        System.out.println("Como deseja pagar: \n"+
                                    "1 ­ Pagamento parcial da conta; \n"+
                                    "2 ­ Pagamento total da conta;");
        
        opcao3= sc.nextInt();
        if(opcao3==1){
            System.out.println("Qual parte você vai pagar: \n"+
                                    "1 ­Qde café expresso; \n"+
                                    "2 ­Qde café capuccino; \n"+
                                      "3 Qde leite com café;");
            opcao3=sc.nextInt();
            if(opcao3 ==1){
                System.out.println("Qde café expresso: "+qde_expresso+" ­ valor: "+valor_expresso);
              }else if(opcao3==2){
                 System.out.println("Qde café capuccino: "+qde_capuccino+" ­ valor: "+valor_capuccino);  
              }else if(opcao3==3){
                 System.out.println("Qde leite com café: "+qde_leite_com_cafe+
                            " ­ valor: "+valor_leite_com_cafe); 
              }
        }else if(opcao3==2){
            System.out.println("Qde cafés vendidos: "+ qde_cafes_vendidos +
                            " ­ valor cafés vendidos: "+valor_cafes_vendidos);
        }
    }
     
    
}
